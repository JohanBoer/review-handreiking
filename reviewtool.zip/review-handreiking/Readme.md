# Reviewtool websites

Lokale review-tool om een willekeurige website van commentaar te voorzien.
Werkt als een proxy: de website wordt via een lokale server geserveerd zodat
je tekstfragmenten kunt selecteren en van opmerkingen kunt voorzien —
vergelijkbaar met de commentaarfunctie in Word.

## 1. Lokaal ophalen

Je hebt geen GitHub-account of git nodig om dit te gebruiken.

- Download [`reviewtool.zip`](reviewtool.zip)
  uit deze repo (bovenaan de bestandenlijst) en pak het uit op je computer.

Vereist is alleen Node.js (v18 of hoger); er hoeft niets extra's geïnstalleerd
te worden (`npm install` is niet nodig).

## 2. Opstarten

Ga naar de uitgepakte map en dubbelklik op het opstartscript voor
jouw besturingssysteem:

- **macOS**: `start-mac.command`
- **Windows**: `start-windows.bat`

Het script controleert of Node.js aanwezig is (en biedt aan dit te installeren
via Homebrew resp. winget, of verwijst naar https://nodejs.org als dat niet
lukt), start daarna de server en opent automatisch http://localhost:3000 in de
browser. Het venster dat opent moet openblijven zolang je de tool gebruikt;
sluiten of Ctrl+C stopt de server.

> macOS kan bij het eerste gebruik een waarschuwing tonen dat het script van
> een "onbekende ontwikkelaar" komt. Ga naar Systeeminstellingen → Privacy en
> beveiliging en kies "Toch openen", of open het script via rechtermuisklik →
> Open.

Liever handmatig starten (of geen dubbelklikbaar script beschikbaar)?

```bash
node server.js
```

De poort is aan te passen via de omgevingsvariabele `PORT`.

Bij het opstarten toont de tool altijd eerst een pop-up waar je je naam invult
en een website kiest: via een dropdown met eerder gereviewde websites, of door
een nieuwe URL in te vullen (bijv. `https://voorbeeld.nl/pagina`). Je naam
wordt onthouden in `config.json` en hoeft niet steeds opnieuw ingevuld te
worden.

## 3. Wat kun je ermee

- Selecteer tekst → klik "💬 Opmerking toevoegen" → typ opmerking → Opslaan
- Geselecteerde tekst wordt geel gemarkeerd in het document
- Klik op een markering om de opmerking te bewerken of te verwijderen
- Zijpaneel (rechtsonder) toont alle opmerkingen op de huidige pagina
- Opmerkingen waarvan de tekst is gewijzigd in de bron worden als ⚠️ gemarkeerd
- Navigeren tussen pagina's van de website werkt gewoon; opmerkingen worden per pagina opgeslagen
- Alle opmerkingen worden opgeslagen in `annotations-<site>.json` (de eerste 10
  letters van de website-URL, zonder `https://www.`); zo houden meerdere
  gereviewde websites hun eigen opmerkingen. Het bestand bevat ook een `site`
  veld met de exacte URL die gereviewd is, plus `reviewer` (jouw naam),
  `firstReviewDate` (datum van de eerste opmerking) en `lastModified` (datum
  van de laatste wijziging)

## 4. Uitwisselen van review-opmerkingen. 

In de map waarin de reviewtool is opgeslagen worden ook de annotatie-bestanden met reviewopmerkingen geplaatst. 
Deze bestanden kan je met een collega uitwisselen. Als deze collega ook deze tool gebruikt kan hij dit bestand in de map zetten waarin deze tool staat en dan zijn de review-opmerkingen beschikbaar via de dropdown in het openingsscherm. 

